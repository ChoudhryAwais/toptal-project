import './App.css';
import Checkout from './Checkout';

function App() {
  return (
    <div className="App">
      <Checkout/>
    </div>
  );
}

export default App;
